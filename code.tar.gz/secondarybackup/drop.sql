drop table Game;
drop table Play;
drop table Player;
drop table Position;
drop table Team;
drop table Term;
drop table Alias;

