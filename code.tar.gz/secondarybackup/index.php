<?php
	header("Location: week.php");
?>

