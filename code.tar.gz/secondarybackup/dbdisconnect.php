<?php
	$db = null;
?>

