<!--div data-role="footer" data-id="samebar" data-position="fixed" data-tap-toggle="false">
	<div data-role="navbar" data-grid="c">
	<ul>
		<li>
			<a href="./weeks.php" id="currentweek">Back to This Week</a>
		</li>
		<li>
			<a href="./weeks.php#<?= $week ?>" id="lastweek">Back to Week <?= $week ?></a>
		</li>
		<li>
			<a href="./game.php" id="lastgame">Back to Game</a>
		</li>
		<li>
			<a href="./search.php" id="search">Look Up a Term</a>
		</li>
	</ul>
	</div>
</div-->

